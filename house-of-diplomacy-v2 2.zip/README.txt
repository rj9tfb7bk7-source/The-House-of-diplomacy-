HOUSE OF DIPLOMACY - REBUILT SITE
Static site, no build step. Deploy the folder root to Vercel (GitHub -> Vercel as before).
After connecting a custom domain: find-replace https://the-house-of-diplomacy.vercel.app in all files, sitemap.xml and robots.txt), then submit sitemap.xml in Google Search Console.
Forms: Join and Submit use your Google Forms. The contact form opens the visitor's email app (no server needed).
Not included on purpose: gate/door, music, cookies, analytics. Add GA4 only with a cookie notice.
