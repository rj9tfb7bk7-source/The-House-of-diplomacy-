HOUSE OF DIPLOMACY — UPDATED WEBSITE PACKAGE

Contents:
- index.html: static website
- image assets and emblem/logo files
- House_of_Diplomacy_Brochure.pdf: public brochure
- House_of_Diplomacy_Invitation.pdf: MUN collaboration brochure
- vercel.json: Vercel clean URL configuration

Updates in this revision:
1. Removed the initial entrance/door ritual and disabled portal/gate overlays.
2. Removed door-based Join/Submit transitions; internal navigation now scrolls normally.
3. Added a comprehensive FAQ section and searchable FAQ entry points.
4. Added an Editorial Standards section covering originality, accuracy, attribution, permissions, review and corrections.
5. Replaced contradictory “form opening soon” copy with one clear contributor form and an email route for MUNs/organisations.
6. Made the collaboration section actionable and linked the existing MUN invitation brochure.
7. Added clear manual certificate-verification instructions without falsely claiming an automated verification database exists.
8. Fixed config-driven links so valid default URLs are not disabled when an optional configuration value is blank.
9. Added FAQ and Editorial Policy links to the footer and site search.

Before deployment:
- Test all links and forms on desktop and mobile.
- Confirm the Google Forms links are the intended live forms.
- The WhatsApp links remain unavailable until valid invite URLs are supplied.
- Certificate verification is currently by email; it is not an automated lookup system.
- Replace or update any content that no longer reflects the actual operating status of the House.

Deploy by uploading the contents of this folder as the static site root, or deploy the folder to Vercel.
