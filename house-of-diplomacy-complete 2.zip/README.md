# House of Diplomacy: site pack
Open `index.html` to run locally, or drag this whole folder onto Vercel.
Includes: cloud-and-flower loading screen, original orchid main page, search icon (also / or Ctrl+K), "How the House works" guide, full "For MUNs" section from your brochures, bluer cleaner design, FAQ/Contact/Privacy/Terms/Copyright/404, sitemap, robots.txt, social tags.
Before launch: swap https://the-house-of-diplomacy.vercel.app for your real domain (all .html files, sitemap.xml, robots.txt); add Search Console/Analytics; review legal pages; confirm permission for credited artwork.
