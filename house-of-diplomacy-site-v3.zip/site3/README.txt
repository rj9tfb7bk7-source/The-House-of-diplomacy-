HOW TO UPLOAD TO GITHUB (easy version: no folders)
1. Open your repository on github.com
2. Add file > Upload files
3. Select index.html AND all the picture files (emblem.png, logo-64.png, image-01... to image-14...) and upload them together
4. Commit changes. Vercel updates the site within about a minute.

All files sit side by side, so there is no images folder to worry about.
The Manto video button needs trigun-pathak-manto-edit.mp4 uploaded to the same place.
