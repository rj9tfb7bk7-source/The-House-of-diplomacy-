HOW TO UPLOAD TO GITHUB
1. Open your repository on github.com
2. Click "Add file" > "Upload files"
3. Drag in index.html AND the whole "images" folder (keep them together)
4. Click "Commit changes"

The page is now about 100 KB instead of 6 MB; pictures load separately and get cached.
The Manto video button needs trigun-pathak-manto-edit.mp4 uploaded to the same repository (next to index.html).
