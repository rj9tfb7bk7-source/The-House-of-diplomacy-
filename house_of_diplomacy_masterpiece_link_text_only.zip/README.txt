HOUSE OF DIPLOMACY — MASTERPIECE WALL UPDATE

This ZIP contains the updated index.html and README only. The Manto feature text and WATCH THE VIDEO link are placed in THE MASTERPIECE WALL section. No MP4 is bundled.

VIDEO LINK CONFIGURATION
The button points to:
https://the-house-of-diplomacy.vercel.app/trigun-pathak-manto-edit.mp4

For that link to play, the MP4 must already be hosted at that exact path in your Vercel deployment (for example, in the public/root static assets for your project). If the MP4 is not hosted there, the button will lead to a missing-file page; an HTML-only ZIP cannot host the video itself.

Deploy the updated index.html with your project.
