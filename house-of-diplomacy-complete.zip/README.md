# House of Diplomacy: deploy pack

## Run it
- Locally: open `index.html` in a browser (everything works from the folder).
- Live: drag this whole folder onto Vercel (or upload the zip contents). `vercel.json` is included.

## What changed
- New front (hero) from your landing page; the gate, page-transition doors, curtains, lamp, drifting vines/dust and all music/sound are removed. Page navigation is instant.
- Blue ambience across the whole site (`assets/css/theme.css`).
- Speed: all inline base64 images moved to cached files (index.html went from 2.9 MB to ~130 KB), lazy-loaded photos, fast reveals.
- Your 11 images are placed through the site (photo bands, stamps, submit and join features, footer logo).
- New pages: faq, contact, privacy, terms, copyright, 404. Plus sitemap.xml, robots.txt, canonical URLs, Open Graph/Twitter tags, schema markup, favicon, manifest, security headers.

## Before launch (needs you)
1. Replace `https://the-house-of-diplomacy.vercel.app` with your real domain in: index.html, the 6 other .html files, sitemap.xml, robots.txt.
2. Add Google Search Console verification, submit sitemap.xml, add GA4 only if you want analytics (and a cookie notice if you do).
3. Review the Privacy, Terms and Copyright text (starter wording, not legal advice).
4. Confirm you have permission for the artwork by @mariumz_world and Sultanabi (credited on the site).
5. Empty settings in the HOUSE_CONFIG block of index.html (WhatsApp links etc.) still show "Coming soon".
6. Test on real iPhone/Android, Safari, Firefox and Edge.
