HOUSE OF DIPLOMACY — REPAIRED STATIC DEPLOYMENT

This package is ready to upload with index.html at the deployment root.

Fixes included:
- Removed dependency on JavaScript for basic content visibility.
- Reveal/motion elements remain readable if an animation observer fails.
- Preserved the existing design, images, PDFs, forms and navigation.
- Added a simple Vercel configuration for clean static routing.
- The Manto video is handled gracefully until the final MP4 is supplied.

To publish: upload the CONTENTS of this folder (not the folder itself) to the repository root.
If you later add the final Manto MP4, name it trigun-pathak-manto-edit.mp4 and place it beside index.html, then restore the video source/button if desired.
