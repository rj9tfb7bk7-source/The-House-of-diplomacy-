# House of Diplomacy: site pack
Open `index.html` to run locally, or drag this folder onto Vercel.

Logos: `assets/img/logo-primary.webp` (footer), `logo-secondary.webp` (desktop header and inner pages), `logo-submark.webp` (mobile header, loading screen, hero watermark), `icon-*.png` + `favicon.ico` (favicon / app icons), `og-image.jpg` (social share).
Pages: index, faq, contact, privacy, terms, refund, cookies, copyright, 404.

Before launch:
- Add `trigun-pathak-manto-edit.mp4` to the site root (the Watch button shows a "temporarily unavailable" message until it exists).
- Replace https://the-house-of-diplomacy.vercel.app with your real domain in all .html files, sitemap.xml and robots.txt.
- Have the legal pages reviewed by a lawyer; confirm permission for all credited artwork.
