/* House of Diplomacy: shared behaviour. No cookies, no storage, no tracking. */
(function () {
  'use strict';
  var d = document;

  /* copyright year: 2026 to current year */
  d.querySelectorAll('[data-year]').forEach(function (el) {
    var y = new Date().getFullYear();
    el.textContent = y > 2026 ? '2026\u2013' + y : '2026';
  });

  /* toast / status messages (success + error) */
  var toastEl = d.getElementById('hx-toast'), toastTimer;
  if (!toastEl) {
    toastEl = d.createElement('div'); toastEl.id = 'hx-toast';
    toastEl.setAttribute('role', 'status'); toastEl.setAttribute('aria-live', 'polite');
    d.body.appendChild(toastEl);
  }
  window.hxToast = function (msg, type) {
    clearTimeout(toastTimer);
    toastEl.className = type === 'error' ? 'error' : '';
    toastEl.setAttribute('role', type === 'error' ? 'alert' : 'status');
    toastEl.textContent = '';
    setTimeout(function () { toastEl.textContent = msg; toastEl.classList.add('show'); }, 30);
    toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, type === 'error' ? 7000 : 3500);
  };

  /* copy buttons */
  d.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copy]'); if (!b) return;
    var text = b.getAttribute('data-copy'), label = b.getAttribute('data-copy-label') || 'Copied';
    function ok() { window.hxToast(label + ' copied to your clipboard.'); }
    function fail() { window.hxToast('Sorry, we could not copy that automatically. Please select it and copy it by hand: ' + text, 'error'); }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(ok, function () { legacy(); });
    } else { legacy(); }
    function legacy() {
      try {
        var t = d.createElement('textarea'); t.value = text; t.setAttribute('readonly', '');
        t.style.cssText = 'position:fixed;top:0;left:0;opacity:0'; d.body.appendChild(t); t.select();
        var done = d.execCommand('copy'); d.body.removeChild(t); done ? ok() : fail();
      } catch (err) { fail(); }
    }
  });

  /* inner-page mobile menu */
  var mb = d.querySelector('.hd-btn'), nav = d.getElementById('hd-nav');
  if (mb && nav) {
    function set(open) {
      nav.classList.toggle('open', open);
      mb.setAttribute('aria-expanded', open ? 'true' : 'false');
      mb.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    }
    mb.addEventListener('click', function () { set(!nav.classList.contains('open')); });
    nav.addEventListener('click', function (e) { if (e.target.closest('a')) set(false); });
    d.addEventListener('keydown', function (e) { if (e.key === 'Escape' && nav.classList.contains('open')) { set(false); mb.focus(); } });
    d.addEventListener('click', function (e) { if (nav.classList.contains('open') && !e.target.closest('.hd')) set(false); });
    window.matchMedia('(min-width:981px)').addEventListener('change', function (m) { if (m.matches) set(false); });
  }

  /* tell screen-reader users when a link opens a new tab */
  d.querySelectorAll('a[target="_blank"]').forEach(function (a) {
    if (a.querySelector('.sr-only')) return;
    var s = d.createElement('span'); s.className = 'sr-only'; s.textContent = ' (opens in a new tab)'; a.appendChild(s);
    var rel = (a.getAttribute('rel') || '').split(' ');
    ['noopener', 'noreferrer'].forEach(function (r) { if (rel.indexOf(r) < 0) rel.push(r); });
    a.setAttribute('rel', rel.join(' ').trim());
  });

  /* media link: if the video file is not reachable, show a clear message instead of a dead button */
  d.querySelectorAll('a[data-check-media]').forEach(function (a) {
    var url = a.getAttribute('href');
    if (!window.fetch || location.protocol === 'file:') return;
    fetch(url, { method: 'HEAD' }).then(function (r) { if (!r.ok) throw 0; }).catch(function () {
      a.removeAttribute('href'); a.setAttribute('aria-disabled', 'true'); a.classList.add('is-placeholder');
      a.textContent = 'VIDEO TEMPORARILY UNAVAILABLE';
      var p = d.createElement('p'); p.className = 'small'; p.setAttribute('role', 'status');
      p.textContent = 'We could not load this video just now. Please try again later or email hello@houseofdiplomacy.com.';
      a.parentNode.insertBefore(p, a.nextSibling);
    });
  });
})();
