HOW TO UPLOAD TO GITHUB (easy version: no folders)
1. Open your repository on github.com
2. Add file > Upload files
3. Select EVERYTHING in this folder (index.html, all pictures, and the two PDFs) and upload together
4. Commit changes. Vercel updates the site within about a minute.

New: a "Brochures" section with the two PDFs (Guide to the House, Invitation to MUNs).
The Manto video button needs trigun-pathak-manto-edit.mp4 uploaded to the same place.
