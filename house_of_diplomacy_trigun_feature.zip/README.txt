HOUSE OF DIPLOMACY — TRIGUN PATHAK FEATURE

Files:
- index.html: updated website HTML with the new House Media feature.
- trigun-pathak-manto-edit.mp4: the submitted video, referenced locally by the HTML.

Keep both files in the same folder. Open index.html locally to preview.
For deployment, upload both files together to the same site directory.

Performance choices:
- Video uses preload="none", so it does not download until a visitor chooses to play it.
- Video scales responsively and uses native browser controls.
- The creator's paragraph is included as supplied; no external video player or JavaScript library was added.
