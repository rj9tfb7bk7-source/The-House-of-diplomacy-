HOUSE OF DIPLOMACY — TRIGUN PATHAK VIDEO FEATURE

Files in this package:
- index.html: updated website page with the Manto editorial feature
- trigun-pathak-manto-edit.mp4: the video used by that feature

IMPORTANT:
Keep index.html and trigun-pathak-manto-edit.mp4 in the same folder. The page references the video with a relative path, so the video will not load if you upload only index.html or rename/move the MP4.

For Vercel:
Upload/deploy the complete project folder so both files are included in the deployment output. If you use a Git repository, commit both files and redeploy. After deployment, open the site and scroll to HOUSE MEDIA / THE POLITICS OF MANTO, then press the video play control.

The video is not set to autoplay; it has visible playback controls and starts when the visitor presses Play.
